
# Mellow pill dispenser
This is a 3D printed platform for dispensing medication everyday.

## for more information check out these links
There will be an update to these links shortly.

https://www.youtube.com/watch?v=qwRPohaCWyw


https://www.patreon.com/posts/pill-dispenser-85981554?utm_medium=clipboard_copy&utm_source=copyLink&utm_campaign=postshare_creator&utm_content=join_link
  
Affiliate links:
Servos: https://amzn.to/3VvYM2y
D1 mini: https://amzn.to/3xaeG9q
Vibration Sensor: https://amzn.to/4b01otY

## Important disclaimer
The pill dispenser is not a 100% reliable solution, I don't recommend using it for essential medication.
It's intended for multivitamins and other supplements, and even then please check whether the pill dispenser has 
dispensed the correct amount.
