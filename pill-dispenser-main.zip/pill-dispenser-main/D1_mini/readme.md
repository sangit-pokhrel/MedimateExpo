
# Mellow pill dispenser V8
This is a 3D printed platform for dispensing medication everyday.
This is code designed to work on the D1 mini with micropython, up to 4 servos and a vibration sensor.

To configure the Script please follow the instructions in the config.py file

## for more information check out these links
There will be an update to these links shortly.

https://www.youtube.com/watch?v=qwRPohaCWyw

https://www.mellowfire.com/post/automatic-pill-dispenser

https://www.printables.com/model/215611-automatic-pill-dispensers

  
  

## Important disclaimer
The pill dispenser is not a 100% reliable solution, I don't recommend using it for essential medication.
It's intended for multivitamins and other supplements, and even then please check whether the pill dispenser has 
dispensed the correct amount.
